from datetime import date
import requests
from f1buddy_ai.chat.intents import Intent, recognize_intent, is_help_request
from f1buddy_ai.chat.history import HistoricalChat
from f1buddy_ai.data.jolpica import JolpicaUnavailable
from f1buddy_ai.models import ChatOption, ChatReply, HostContext
from f1buddy_ai.services.f1_data import F1DataService, DataUnavailable

QUICK_ACTIONS = [
    ChatOption(label="🏁 Next race", command="next race"),
    ChatOption(label="🏎️ Driver standings", command="driver standings"),
    ChatOption(label="🏆 Constructor standings", command="constructor standings"),
    ChatOption(label="🔮 Current prediction", command="current prediction"),
    ChatOption(label="📊 Model performance", command="model performance"),
]


class ChatEngine:
    def __init__(self, service: F1DataService, context: HostContext, *, saved_only: bool = False):
        self.service = service
        self.context = context
        self.history = HistoricalChat(service.repository, service.jolpica)
        self.saved_only = saved_only
        self.quick_actions = [
            ChatOption(label="🔮 Saved prediction", command="saved prediction")
            if saved_only and option.command == "current prediction" else option
            for option in QUICK_ACTIONS
        ]

    def respond(self, message: str) -> ChatReply:
        season = self.context.current_race.season if self.context.current_race else self.context.as_of_date.year
        historical = self.history.respond(message, season)
        if historical is not None:
            return historical
        intent = recognize_intent(message)
        if intent == Intent.HELP:
            prefix = ("Hi! I'm F1 Buddy. " if is_help_request(message)
                      else "I can't analyse open-ended F1 questions in Phase 1. ")
            prediction_label = "latest saved prediction" if self.saved_only else "current prediction"
            return ChatReply(text=prefix + f"I can show the next race, standings, the {prediction_label}, or model performance. "
                             "For previous races, try 'Mexico 2025 prediction', 'Mexico predicted qualifying', "
                             "'Mexico prediction after qualifying', or 'United States 2025 race results'. "
                             "Without a year I use the displayed race's season (or the selected date's year). Missing predictions are never regenerated. "
                             "Choose an option below.",
                             intent=intent.value, options=self.quick_actions)
        try:
            if intent == Intent.NEXT_RACE:
                result = self.service.next_race(self.context)
                race = result.data
                text = f"{race.name} — round {race.round}, {race.season}\n\nRace date: {race.date.isoformat()}"
                if race.raceStartUtc:
                    text += f"\n\nStart: {race.raceStartUtc.isoformat()} (UTC)"
                else:
                    text += "\n\nExact start time is not available in this saved data."
                for name, start in race.sessions.items():
                    if start:
                        text += f"\n\n{name}: {start.isoformat()} (UTC)"
            elif intent == Intent.DRIVER_STANDINGS:
                result = self.service.driver_standings(date.today().year)
                text = "Latest saved driver standings (not historical standings for the selected date):\n\n"
                text += "\n\n".join(f"{r.position}. {r.name} — {r.points:g} points" for r in result.data[:10])
            elif intent == Intent.CONSTRUCTOR_STANDINGS:
                result = self.service.constructor_standings(date.today().year)
                text = "Latest saved constructor standings (not historical standings for the selected date):\n\n"
                text += "\n\n".join(f"{r.position}. {r.name} — {r.points:g} points" for r in result.data[:10])
            elif intent == Intent.CURRENT_PREDICTION:
                if self.saved_only:
                    result = self.service.saved_prediction()
                    saved = result.data
                    mode = "real qualifying grid" if saved.has_real_grid else "predicted qualifying grid"
                    text = (f"Latest saved prediction — {saved.race.name}, {saved.race.season}, round {saved.race.round}\n\n"
                            f"Snapshot as-of: {saved.as_of.isoformat()}. Race date: {saved.race.date.isoformat()}.\n\n"
                            "This is not a live prediction from your Streamlit dashboard; it may be for a past race.\n\n"
                            f"Podium probabilities using the {mode}:\n\n")
                    rows = saved.podium
                else:
                    result = self.service.current_prediction(self.context)
                    mode = "real qualifying grid" if self.context.has_real_grid else "predicted qualifying grid"
                    text = f"Podium probabilities using the {mode}:\n\n"
                    rows = result.data
                text += "\n\n".join(f"{r.driverName} — {r.podiumProbability:.1%}" for r in rows[:3])
                text += "\n\nThese estimate a top-three finish, not a race win. They are model estimates, not guarantees."
            else:
                result = self.service.model_performance()
                metrics = result.data
                text = (f"Saved offline model evaluation (separate from the live accuracy panel):\n\n"
                        f"ROC AUC: {metrics.roc_auc:.3f}\n\n"
                        f"Top-one accuracy: {metrics.top1_accuracy:.1%}\n\n"
                        f"Top-three accuracy: {metrics.top3_accuracy:.1%}\n\n"
                        f"Test driver-race rows: {metrics.test_rows}")
            text += f"\n\nSource: {result.source}."
            if result.generated_at:
                label = "Standings updated" if intent in (Intent.DRIVER_STANDINGS, Intent.CONSTRUCTOR_STANDINGS) else "Prediction snapshot generated"
                text += f" {label}: {result.generated_at.isoformat()}."
            return ChatReply(text=text, intent=intent.value,
                             metadata={"source": result.source})
        except (DataUnavailable, JolpicaUnavailable, requests.RequestException,
                OSError, KeyError, ValueError, TypeError, AttributeError, IndexError):
            return ChatReply(text="That data is temporarily unavailable. Please try again later or choose another option.",
                             intent=intent.value, options=self.quick_actions)
