"""Read existing historical forecasts and clearly separate them from actual results."""
from __future__ import annotations

import re
import unicodedata
from typing import Any

import requests

from f1buddy_ai.data.jolpica import JolpicaUnavailable
from f1buddy_ai.models import ChatReply

DATA_ERRORS = (OSError, KeyError, ValueError, TypeError, AttributeError, IndexError,
               requests.RequestException, JolpicaUnavailable)


def normalise(text: str) -> str:
    ascii_text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode()
    return " ".join(re.sub(r"[^a-z0-9 ]", " ", ascii_text.lower()).split())


def contains(text: str, phrase: str) -> bool:
    return f" {phrase} " in f" {text} "


# Names, not round numbers: resolve the season's actual round from saved/API metadata.
ALIASES = {
    "mexico": "Mexico City Grand Prix", "mexican gp": "Mexico City Grand Prix",
    "united states": "United States Grand Prix", "us gp": "United States Grand Prix",
    "austin": "United States Grand Prix", "cota": "United States Grand Prix",
    "brazil": "São Paulo Grand Prix", "brazilian gp": "São Paulo Grand Prix",
    "sao paulo": "São Paulo Grand Prix", "interlagos": "São Paulo Grand Prix",
    "miami": "Miami Grand Prix", "las vegas": "Las Vegas Grand Prix",
    "australia": "Australian Grand Prix", "australian": "Australian Grand Prix",
    "china": "Chinese Grand Prix", "chinese": "Chinese Grand Prix",
    "japan": "Japanese Grand Prix", "japanese": "Japanese Grand Prix",
    "bahrain": "Bahrain Grand Prix", "saudi arabia": "Saudi Arabian Grand Prix",
    "saudi arabian": "Saudi Arabian Grand Prix", "monaco": "Monaco Grand Prix",
    "canada": "Canadian Grand Prix", "canadian": "Canadian Grand Prix",
    "spain": "Spanish Grand Prix", "spanish": "Spanish Grand Prix",
    "austria": "Austrian Grand Prix", "austrian": "Austrian Grand Prix",
    "britain": "British Grand Prix", "british": "British Grand Prix",
    "silverstone": "British Grand Prix", "belgium": "Belgian Grand Prix",
    "belgian": "Belgian Grand Prix", "hungary": "Hungarian Grand Prix",
    "hungarian": "Hungarian Grand Prix", "netherlands": "Dutch Grand Prix",
    "dutch": "Dutch Grand Prix", "italian": "Italian Grand Prix",
    "monza": "Italian Grand Prix", "emilia romagna": "Emilia Romagna Grand Prix",
    "imola": "Emilia Romagna Grand Prix", "azerbaijan": "Azerbaijan Grand Prix",
    "baku": "Azerbaijan Grand Prix", "singapore": "Singapore Grand Prix",
    "qatar": "Qatar Grand Prix", "abu dhabi": "Abu Dhabi Grand Prix",
}


def identity(record: Any) -> tuple[int, int] | None:
    if not isinstance(record, dict):
        return None
    try:
        season, rnd = int(record["season"]), int(record["round"])
        return (season, rnd) if season >= 1950 and rnd > 0 else None
    except (KeyError, ValueError, TypeError):
        return None


class HistoricalChat:
    def __init__(self, repository, api):
        self.repository = repository
        self.api = api

    def _read(self, name: str, default):
        try:
            value = self.repository._read(name)
            return value if isinstance(value, type(default)) else default
        except DATA_ERRORS:
            return default

    def _catalog(self) -> list[dict]:
        rows = [row for row in self._read("races.json", [])
                if identity(row) and isinstance(row.get("name"), str)]
        snapshot = self._read("next_race_prediction.json", {})
        candidate = snapshot.get("race")
        if identity(candidate) and isinstance(candidate.get("name"), str):
            # The calendar takes precedence over conflicting snapshot metadata.
            known = any(identity(row)[0] == identity(candidate)[0]
                        and normalise(row["name"]) == normalise(candidate["name"])
                        for row in rows)
            if not known:
                rows.append(candidate)
        return rows

    def _api_races(self, path: str) -> list[dict]:
        if self.api is None:
            raise JolpicaUnavailable("No fallback client configured")
        payload = self.api._get(path)
        rows = payload["MRData"]["RaceTable"]["Races"]
        if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
            raise ValueError("Invalid race response")
        return rows

    def _resolve(self, name: str, season: int, catalog: list[dict]) -> dict:
        matches = [row for row in catalog if identity(row)[0] == season
                   and normalise(row["name"]) == normalise(name)]
        if not matches:
            rows = self._api_races(f"{season}/?limit=100")
            matches = []
            for row in rows:
                event_name = row.get("raceName", row.get("name"))
                if identity(row) and identity(row)[0] == season and isinstance(event_name, str):
                    if normalise(event_name) == normalise(name):
                        matches.append({**row, "name": event_name})
        if len({identity(row) for row in matches}) != 1:
            raise ValueError("Race not uniquely resolved")
        return matches[0]

    def _forecast(self, race: dict) -> dict:
        snapshot = self._read("next_race_prediction.json", {})
        if identity(snapshot.get("race")) != identity(race):
            return {}
        forecast = snapshot.get("forecast")
        if not isinstance(forecast, dict):
            return {}
        if identity(forecast.get("race", snapshot["race"])) != identity(race):
            return {}
        return forecast

    @staticmethod
    def _saved(rows, label: str, probability: bool = True) -> str | None:
        if not isinstance(rows, list) or not rows:
            return None
        try:
            lines = []
            for index, row in enumerate(rows[:3 if probability else 10], 1):
                if not isinstance(row, dict):
                    return None
                name = row.get("driverName") or row.get("code") or row.get("driver")
                if not isinstance(name, str) or not name:
                    return None
                if probability:
                    value = float(row["podiumProbability"])
                    if not 0 <= value <= 1:
                        return None
                    lines.append(f"{name} — {value * 100:g}%")
                else:
                    detail = "; ".join(f"{q}: {row[q]}" for q in ("Q1", "Q2", "Q3") if row.get(q))
                    lines.append(f'{row.get("position", index)}. {name}' + (f" — {detail}" if detail else ""))
            return label + "\n\n" + "\n\n".join(lines)
        except DATA_ERRORS:
            return None

    def _actual(self, race: dict, forecast: dict, qualifying: bool = False) -> str:
        label = "Actual qualifying classification" if qualifying else "Actual race finishing classification"
        note = "\n\nQualifying classification may differ from the starting grid after penalties." if qualifying else ""
        if qualifying and forecast.get("hasRealGrid") is True:
            saved = self._saved(forecast.get("realQualifying"), label + " — saved snapshot", False)
            if saved:
                return saved + note
        kind, field = ("qualifying", "QualifyingResults") if qualifying else ("results", "Results")
        season, rnd = identity(race)
        try:
            races = self._api_races(f"{season}/{rnd}/{kind}/?limit=100")
            matches = [row for row in races if identity(row) == (season, rnd)]
            if races and not matches:
                raise ValueError("Response is for a different race")
            rows = matches[0].get(field, []) if matches else []
            if not isinstance(rows, list):
                raise ValueError("Invalid results")
            if not rows:
                return label + ": not published or not available in Jolpica yet."
            lines = []
            for row in rows[:10]:
                driver = row["Driver"]
                name = f'{driver["givenName"]} {driver["familyName"]}'
                if qualifying:
                    detail = "; ".join(f"{q}: {row[q]}" for q in ("Q1", "Q2", "Q3") if row.get(q))
                else:
                    detail = row.get("status", "")
                lines.append(f'{row["position"]}. {name}' + (f" — {detail}" if detail else ""))
            return label + " — Jolpica\n\n" + "\n\n".join(lines) + note
        except DATA_ERRORS:
            return label + ": temporarily unavailable; the source could not be read."

    def respond(self, message: str, default_season: int) -> ChatReply | None:
        text = normalise(message)
        catalog = self._catalog()
        aliases = dict(ALIASES)
        for row in catalog:
            phrase = normalise(row["name"]).removesuffix(" grand prix").strip()
            if phrase:
                aliases[phrase] = row["name"]
        # Normalize names too, so Sao/São Paulo aliases cannot form two events.
        names = {normalise(name): name for phrase, name in aliases.items() if contains(text, phrase)}
        reply = lambda body: ChatReply(text=body, intent="history")
        generic_us = contains(text, "usa") or (contains(text, "us") and not contains(text, "us gp"))
        if generic_us and not names:
            return reply("Please specify United States GP (Austin), Miami GP, or Las Vegas GP and, if needed, the year.")
        if not names:
            if any(contains(text, phrase) for phrase in ("history", "historical", "previous race", "last race", "grand prix")):
                return reply("Please specify a race I can identify, such as 'Mexico prediction' or 'United States 2025 race results'.")
            return None
        if len(names) != 1:
            return reply("Please specify one named race at a time and include its year if needed.")
        if contains(text, "sprint"):
            return reply("Sprint results are not supported in Phase 1. Ask for Grand Prix race or qualifying results.")
        years = re.findall(r"\b(?:19|20)\d{2}\b", text)
        if len(set(years)) > 1:
            return reply("Please specify one season for this race.")
        season = int(years[0]) if years else default_season
        try:
            race = self._resolve(next(iter(names.values())), season, catalog)
            forecast = self._forecast(race)
        except DATA_ERRORS:
            return reply(f"I could not identify that race for {season}. Please specify its name/year or try again when the schedule source is available.")
        prediction = bool(re.search(r"\b(predict|predicted|prediction|predictions|forecast)\b", text))
        actual = bool(re.search(r"\b(result|results|compare|actual|qualified)\b", text))
        qualifying = bool(re.search(r"\b(qualifying|qualified|quali)\b", text))
        if not prediction and not actual and not qualifying:
            prediction = actual = True
        if qualifying and not prediction:
            actual = True
        after = bool(re.search(r"(after (the )?(real )?qualifying|post qualifying|real grid)", text))
        before = "before qualifying" in text or "pre qualifying" in text
        qualifying_prediction = prediction and qualifying and not after and not before
        parts = [f'{race["name"]} — {season} (round {race["round"]})']
        missing = False
        if prediction:
            stages = [
                ("predictedQualifying", "Predicted qualifying order", False),
                ("preQualifyingPodium", "Pre-qualifying podium probabilities", True),
                ("realGridPodium", "Post-qualifying podium probabilities", True),
            ]
            wanted = [stages[0]] if qualifying_prediction else [stages[2]] if after else [stages[1]] if before else stages
            found, absent = [], []
            for key, label, probability in wanted:
                rows = forecast.get(key) if key != "realGridPodium" or forecast.get("hasRealGrid") is True else None
                section = self._saved(rows, label + " — saved next_race_prediction.json", probability)
                if section:
                    found.append(section)
                else:
                    absent.append(label)
            if not found and not (after or before or qualifying_prediction):
                records = self._read("predictions.json", {})
                section = self._saved(records.get(f"{season}-{identity(race)[1]}"),
                    "Saved historical model estimate — qualifying stage and original forecast time unknown — predictions.json")
                if section:
                    found.append(section)
                    absent = []
            parts.extend(found)
            missing = bool(absent) or not found
            parts.extend(f"{label}: unavailable in saved outputs." for label in absent)
            if not found:
                parts.append("The requested saved prediction is unavailable. Actual results are shown separately when available.")
            else:
                parts.append("These are saved model outputs, not proof of forecasts published before the event. Podium probabilities are not win probabilities.")
        if actual or missing:
            if qualifying:
                parts.append(self._actual(race, forecast, qualifying=True))
            if not qualifying or missing or contains(text, "race results") or contains(text, "race result"):
                parts.append(self._actual(race, forecast))
        return reply("\n\n".join(parts))
