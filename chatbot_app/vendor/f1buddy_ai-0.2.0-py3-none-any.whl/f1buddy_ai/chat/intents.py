from __future__ import annotations

import re
from enum import Enum


class Intent(str, Enum):
    NEXT_RACE = "next_race"
    DRIVER_STANDINGS = "driver_standings"
    CONSTRUCTOR_STANDINGS = "constructor_standings"
    CURRENT_PREDICTION = "current_prediction"
    MODEL_PERFORMANCE = "model_performance"
    HELP = "help"


def _normalise(message: str) -> str:
    return " ".join(re.sub(r"[^a-z0-9 ]+", " ", message.lower()).split())


def is_help_request(message: str) -> bool:
    return _normalise(message) in {"", "help", "menu", "what can you do", "commands", "hi", "hello"}


def recognize_intent(message: str) -> Intent:
    text = _normalise(message)
    if is_help_request(message):
        return Intent.HELP
    if any(word in text for word in ("accuracy", "accurate", "performance", "roc auc", "top 3")):
        return Intent.MODEL_PERFORMANCE
    if any(word in text for word in ("constructor", "constructors", "team standings", "team championship")):
        return Intent.CONSTRUCTOR_STANDINGS
    if re.search(r"\b(prediction|predicted|predict|win|podium)\b", text):
        return Intent.CURRENT_PREDICTION
    if any(word in text for word in ("driver standings", "driver championship", "standings", "championship")):
        return Intent.DRIVER_STANDINGS
    if any(word in text for word in ("next race", "schedule", "when is", "grand prix")):
        return Intent.NEXT_RACE
    return Intent.HELP
