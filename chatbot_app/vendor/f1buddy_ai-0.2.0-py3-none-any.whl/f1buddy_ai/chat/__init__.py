"""F1 Buddy read-only chatbot components."""
