from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from f1buddy_ai.models import (
    ConstructorStanding,
    DriverStanding,
    ModelPerformance,
    PodiumPrediction,
    RaceInfo,
    SavedPrediction,
)


class SnapshotRepository:
    def __init__(self, data_dir: str | Path):
        self.data_dir = Path(data_dir)

    def _read(self, name: str):
        path = self.data_dir / name
        return json.loads(path.read_text(encoding="utf-8"))

    def generated_at(self) -> datetime | None:
        value = self._read("next_race_prediction.json").get("generatedAt")
        return datetime.fromisoformat(value.replace("Z", "+00:00")) if value else None

    def prediction_as_of(self) -> str:
        return self._read("next_race_prediction.json")["asof"]

    def standings_timestamp(self) -> datetime:
        return datetime.fromisoformat(self._read("stats.json")["updatedAt"].replace("Z", "+00:00"))

    def next_race(self) -> RaceInfo:
        return RaceInfo.model_validate(self._read("next_race_prediction.json")["race"])

    def driver_standings(self) -> list[DriverStanding]:
        rows = self._read("stats.json")["drivers"]
        if not rows:
            raise ValueError("Empty driver standings")
        return [
            DriverStanding(
                position=int(row["position"]),
                code=row["code"],
                name=f'{row["givenName"]} {row["familyName"]}',
                team=row["constructorName"],
                points=row["points"],
                wins=row["wins"],
            )
            for row in sorted(rows, key=lambda r: int(r["position"]))
        ]

    def constructor_standings(self) -> list[ConstructorStanding]:
        rows = self._read("stats.json")["constructors"]
        if not rows:
            raise ValueError("Empty constructor standings")
        return [
            ConstructorStanding(position=int(row["position"]), id=row["constructorId"],
                                name=row["name"], points=row["points"], wins=row["wins"])
            for row in sorted(rows, key=lambda r: int(r["position"]))
        ]

    def current_prediction(self, use_real_grid: bool = False) -> list[PodiumPrediction]:
        payload = self._read("next_race_prediction.json")
        return self._prediction_rows(payload, use_real_grid)

    @staticmethod
    def _prediction_rows(payload: dict, use_real_grid: bool) -> list[PodiumPrediction]:
        forecast = payload["forecast"]
        outer = payload["race"]
        inner = forecast.get("race", outer)
        if (str(inner["season"]), str(inner["round"])) != (str(outer["season"]), str(outer["round"])):
            raise ValueError("Conflicting snapshot race identity")
        if use_real_grid and forecast.get("hasRealGrid") is not True:
            raise ValueError("Real qualifying grid is not confirmed")
        rows = (forecast.get("realGridPodium") if use_real_grid
                else forecast["preQualifyingPodium"])
        if not rows:
            raise ValueError("Requested prediction mode unavailable")
        return [PodiumPrediction.model_validate(row) for row in rows]

    def saved_prediction(self) -> SavedPrediction:
        # Read once so identity, as-of date and selected rows belong to one snapshot.
        payload = self._read("next_race_prediction.json")
        forecast = payload["forecast"]
        if "hasRealGrid" in forecast and not isinstance(forecast["hasRealGrid"], bool):
            raise ValueError("Invalid qualifying grid confirmation")
        if "asof" in forecast and forecast["asof"] != payload["asof"]:
            raise ValueError("Conflicting snapshot as-of dates")
        inner_race = forecast.get("race", payload["race"])
        if "date" in inner_race and inner_race["date"] != payload["race"]["date"]:
            raise ValueError("Conflicting snapshot race dates")
        confirmed = forecast.get("hasRealGrid") is True
        return SavedPrediction(
            race=RaceInfo.model_validate(payload["race"]), as_of=payload["asof"],
            has_real_grid=confirmed, podium=self._prediction_rows(payload, confirmed),
        )

    def model_performance(self) -> ModelPerformance:
        podium = self._read("metrics.json")["podium"]
        return ModelPerformance(
            roc_auc=podium["rocAuc"],
            top1_accuracy=podium["top1Accuracy"],
            top3_accuracy=podium["top3Accuracy"],
            test_rows=podium["testRows"],
        )
