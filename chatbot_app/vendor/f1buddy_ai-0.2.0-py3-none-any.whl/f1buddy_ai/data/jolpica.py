from __future__ import annotations

import time
import math
from collections import deque
from datetime import date, datetime, timezone
from email.utils import parsedate_to_datetime
from threading import Lock

import requests

from f1buddy_ai.models import ConstructorStanding, DriverStanding, RaceInfo


class JolpicaUnavailable(RuntimeError):
    pass


class JolpicaClient:
    BASE_URL = "https://api.jolpi.ca/ergast/f1"

    def __init__(
        self,
        min_interval_seconds: float = 1.0,
        max_retries: int = 3,
        timeout_seconds: float = 5.0,
        hourly_budget: int = 60,
    ):
        self.min_interval_seconds = min_interval_seconds
        self.max_retries = max_retries
        self.timeout_seconds = timeout_seconds
        self.hourly_budget = hourly_budget
        self._attempts = deque()
        self._cache = {}
        self._blocked_until = 0.0
        self._lock = Lock()
        self._last_request = 0.0
        self._session = requests.Session()
        self._session.headers["User-Agent"] = "f1buddy-ai/0.1.0"

    def _get(self, path: str) -> dict:
        with self._lock:
            now = time.monotonic()
            cached = self._cache.get(path)
            if cached and now - cached[0] < 900:
                return cached[1]
            if now < self._blocked_until:
                raise JolpicaUnavailable("Fallback cooling down")
            for attempt in range(self.max_retries):
                now = time.monotonic()
                while self._attempts and now - self._attempts[0] >= 3600:
                    self._attempts.popleft()
                if len(self._attempts) >= self.hourly_budget:
                    raise JolpicaUnavailable("Fallback hourly budget exhausted")
                time.sleep(max(0, self.min_interval_seconds - (now - self._last_request)))
                self._last_request = time.monotonic()
                self._attempts.append(self._last_request)
                wait = 2 ** attempt
                try:
                    response = self._session.get(
                        f"{self.BASE_URL}/{path}", timeout=self.timeout_seconds
                    )
                    if response.status_code == 429 or response.status_code >= 500:
                        raw_wait = response.headers.get("Retry-After")
                        if raw_wait:
                            try:
                                wait = float(raw_wait)
                            except ValueError:
                                try:
                                    wait = (parsedate_to_datetime(raw_wait) - datetime.now(timezone.utc)).total_seconds()
                                except (ValueError, TypeError, OverflowError):
                                    wait = 60
                            if not math.isfinite(wait):
                                wait = 60
                            wait = max(0, wait)
                        if wait > 8:
                            self._blocked_until = time.monotonic() + wait
                            raise JolpicaUnavailable("Server requested a longer cooldown")
                    else:
                        response.raise_for_status()
                        payload = response.json()
                        self._cache[path] = (time.monotonic(), payload)
                        return payload
                except requests.RequestException:
                    pass
                if attempt + 1 < self.max_retries:
                    time.sleep(wait)
            self._blocked_until = time.monotonic() + 60
            raise JolpicaUnavailable("Fallback attempts exhausted")

    def driver_standings(self, season: int) -> list[DriverStanding]:
        payload = self._get(f"{season}/driverstandings/?limit=100")
        lists = payload["MRData"].get("StandingsTable", {}).get("StandingsLists", [])
        rows = lists[0].get("DriverStandings", []) if lists else []
        if not rows:
            raise JolpicaUnavailable("Jolpica returned no driver standings")
        return [
            DriverStanding(
                position=int(row["position"]),
                code=row["Driver"].get("code", row["Driver"]["driverId"][:3].upper()),
                name=f'{row["Driver"]["givenName"]} {row["Driver"]["familyName"]}',
                team=row.get("Constructors", [{}])[0].get("name", "Unknown"),
                points=float(row["points"]),
                wins=int(row["wins"]),
            )
            for row in rows
        ]

    def constructor_standings(self, season: int) -> list[ConstructorStanding]:
        payload = self._get(f"{season}/constructorstandings/?limit=100")
        lists = payload["MRData"].get("StandingsTable", {}).get("StandingsLists", [])
        rows = lists[0].get("ConstructorStandings", []) if lists else []
        if not rows:
            raise JolpicaUnavailable("Jolpica returned no constructor standings")
        return [
            ConstructorStanding(
                position=int(row["position"]),
                id=row["Constructor"]["constructorId"],
                name=row["Constructor"]["name"],
                points=float(row["points"]),
                wins=int(row["wins"]),
            )
            for row in rows
        ]

    def next_race(self, as_of: date) -> RaceInfo:
        payload = self._get(f"{as_of.year}/?limit=100")
        rows = payload["MRData"].get("RaceTable", {}).get("Races", [])
        rows = sorted((row for row in rows if date.fromisoformat(row["date"]) >= as_of),
                      key=lambda row: row["date"])
        if not rows:
            raise JolpicaUnavailable("Jolpica returned no next race")
        row = rows[0]
        start = None
        if row.get("date") and row.get("time"):
            start = f'{row["date"]}T{row["time"]}'
        return RaceInfo(
            name=row["raceName"],
            season=int(row["season"]),
            round=int(row["round"]),
            country=row["Circuit"].get("Location", {}).get("country"),
            date=date.fromisoformat(row["date"]),
            raceStartUtc=start,
            qualifyingDate=row.get("Qualifying", {}).get("date"),
            sessions={
                label: f'{session["date"]}T{session["time"]}'
                for key, label in (("FirstPractice", "firstPractice"),
                                   ("SecondPractice", "secondPractice"),
                                   ("ThirdPractice", "thirdPractice"),
                                   ("Qualifying", "qualifying"),
                                   ("Sprint", "sprint"),
                                   ("SprintQualifying", "sprintQualifying"))
                if (session := row.get(key)) and session.get("date") and session.get("time")
            },
        )
