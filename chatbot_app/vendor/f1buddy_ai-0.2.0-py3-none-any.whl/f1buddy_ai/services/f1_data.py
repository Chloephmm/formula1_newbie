from __future__ import annotations

from f1buddy_ai.data.jolpica import JolpicaClient
from f1buddy_ai.data.snapshots import SnapshotRepository
from f1buddy_ai.models import DataResult, HostContext

SOURCE_ERRORS = (OSError, KeyError, ValueError, TypeError, AttributeError, IndexError)


class DataUnavailable(RuntimeError):
    pass


class F1DataService:
    def __init__(self, repository: SnapshotRepository, jolpica: JolpicaClient | None):
        self.repository = repository
        self.jolpica = jolpica

    def _fallback(self, method: str, *args):
        if self.jolpica is None:
            raise DataUnavailable("No fallback client configured")
        return getattr(self.jolpica, method)(*args)

    def _generated_at(self):
        try:
            return self.repository.generated_at()
        except SOURCE_ERRORS:
            return None

    def next_race(self, context: HostContext):
        if context.current_race is not None:
            return DataResult(data=context.current_race, source="streamlit-page")
        try:
            race = self.repository.next_race()
            if race.date < context.as_of_date or self.repository.prediction_as_of() != context.as_of_date.isoformat():
                raise ValueError("Snapshot does not match selected date")
            return DataResult(
                data=race,
                source="formula1-newbie",
                generated_at=self._generated_at(),
            )
        except SOURCE_ERRORS:
            return DataResult(
                data=self._fallback("next_race", context.as_of_date), source="jolpica"
            )

    def driver_standings(self, season: int):
        try:
            return DataResult(
                data=self.repository.driver_standings(),
                source="formula1-newbie",
                generated_at=self.repository.standings_timestamp(),
            )
        except SOURCE_ERRORS:
            return DataResult(data=self._fallback("driver_standings", season), source="jolpica")

    def constructor_standings(self, season: int):
        try:
            return DataResult(
                data=self.repository.constructor_standings(),
                source="formula1-newbie",
                generated_at=self.repository.standings_timestamp(),
            )
        except SOURCE_ERRORS:
            return DataResult(
                data=self._fallback("constructor_standings", season), source="jolpica"
            )

    def current_prediction(self, context: HostContext):
        if context.current_prediction is not None:
            if not context.current_prediction:
                raise DataUnavailable("Empty host prediction")
            return DataResult(data=context.current_prediction, source="streamlit-page")
        try:
            if self.repository.prediction_as_of() != context.as_of_date.isoformat():
                raise ValueError("Snapshot does not match selected date")
            race = self.repository.next_race()
            if context.current_race and (race.season, race.round) != (
                context.current_race.season, context.current_race.round
            ):
                raise ValueError("Snapshot does not match displayed race")
            return DataResult(
                data=self.repository.current_prediction(use_real_grid=context.has_real_grid),
                source="formula1-newbie",
                generated_at=self._generated_at(),
            )
        except SOURCE_ERRORS as exc:
            raise DataUnavailable("Current prediction is unavailable") from exc

    def model_performance(self):
        try:
            return DataResult(
                data=self.repository.model_performance(),
                source="formula1-newbie",
            )
        except SOURCE_ERRORS as exc:
            raise DataUnavailable("Model performance is unavailable") from exc

    def saved_prediction(self):
        try:
            return DataResult(data=self.repository.saved_prediction(), source="formula1-newbie saved snapshot")
        except SOURCE_ERRORS as exc:
            raise DataUnavailable("Saved prediction is unavailable") from exc
