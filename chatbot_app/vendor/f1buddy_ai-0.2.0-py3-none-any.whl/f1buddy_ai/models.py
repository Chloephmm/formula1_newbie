from __future__ import annotations

from datetime import date, datetime
from typing import Any, Generic, TypeVar

from pydantic import BaseModel, Field

T = TypeVar("T")


class RaceInfo(BaseModel):
    name: str
    season: int
    round: int
    country: str | None = None
    date: date
    qualifyingDate: date | None = None
    raceStartUtc: datetime | None = None
    sessions: dict[str, datetime | None] = Field(default_factory=dict)


class DriverStanding(BaseModel):
    position: int
    code: str
    name: str
    team: str
    points: float
    wins: int


class ConstructorStanding(BaseModel):
    position: int
    id: str
    name: str
    points: float
    wins: int


class PodiumPrediction(BaseModel):
    code: str
    driverName: str
    team: str
    podiumProbability: float = Field(ge=0.0, le=1.0)


class ModelPerformance(BaseModel):
    roc_auc: float
    top1_accuracy: float
    top3_accuracy: float
    test_rows: int


class SavedPrediction(BaseModel):
    race: RaceInfo
    as_of: date
    has_real_grid: bool
    podium: list[PodiumPrediction] = Field(min_length=1)


class DataResult(BaseModel, Generic[T]):
    data: T
    source: str
    generated_at: datetime | None = None
    stale: bool = False


class HostContext(BaseModel):
    as_of_date: date
    current_race: RaceInfo | None = None
    has_real_grid: bool = False
    current_prediction: list[PodiumPrediction] | None = None


class ChatOption(BaseModel):
    label: str
    command: str


class ChatReply(BaseModel):
    text: str
    intent: str
    options: list[ChatOption] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)
