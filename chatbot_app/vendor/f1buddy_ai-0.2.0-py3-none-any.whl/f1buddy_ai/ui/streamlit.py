from datetime import date
from pathlib import Path
from collections.abc import Mapping

import streamlit as st

from f1buddy_ai.chat.engine import ChatEngine
from f1buddy_ai.data.jolpica import JolpicaClient
from f1buddy_ai.data.snapshots import SnapshotRepository
from f1buddy_ai.services.f1_data import F1DataService
from f1buddy_ai.ui.adapter import context_from_display
from f1buddy_ai.models import HostContext


@st.cache_resource
def _jolpica_client() -> JolpicaClient:
    # A separate client: never reuse or clear the prediction application's cache.
    return JolpicaClient()


@st.fragment
def render_chatbot(
    *, data_dir: str | Path, as_of_date: date,
    displayed_race: Mapping | None, has_real_grid: bool,
    driver_names: Mapping[str, str], team_names: Mapping[str, str],
    state_key: str = "f1buddy",
) -> None:
    try:
        context = context_from_display(
            as_of_date=as_of_date, displayed_race=displayed_race,
            has_real_grid=has_real_grid, driver_names=driver_names,
            team_names=team_names,
        )
    except (KeyError, ValueError, TypeError):
        with st.popover("💬 Ask F1 Buddy"):
            st.info("The displayed prediction is unavailable to the chatbot.")
        return
    with st.popover("💬 Ask F1 Buddy"):
        st.caption("Existing F1 data and the prediction currently on this page.")
        _conversation(data_dir, context, state_key, saved_only=False)


@st.fragment
def render_chatbot_panel(
    *, data_dir: str | Path, as_of_date: date | None = None,
    state_key: str = "f1buddy_panel",
) -> None:
    """Chat-only entrypoint for embedding; never imports or runs a prediction engine."""
    st.caption("Read-only saved F1 outputs. Predictions may be older than today; no model runs here.")
    _conversation(data_dir, HostContext(as_of_date=as_of_date or date.today()), state_key, saved_only=True)


def _conversation(data_dir, context: HostContext, state_key: str, *, saved_only: bool):
    engine = ChatEngine(F1DataService(SnapshotRepository(data_dir), _jolpica_client()),
                        context, saved_only=saved_only)
    history_key = f"{state_key}_messages"
    context_key = f"{state_key}_context"
    fingerprint = context.model_dump_json()
    if st.session_state.get(context_key) != fingerprint or history_key not in st.session_state:
        st.session_state[context_key] = fingerprint
        st.session_state[history_key] = [
            {"role": "assistant", "content": engine.respond("help").text}
        ]
    command = None
    # Populate this reserved transcript after handling the current event.
    transcript = st.container(height=300 if saved_only else 360)
    columns = st.columns(2)
    for index, option in enumerate(engine.quick_actions):
        if columns[index % 2].button(option.label, key=f"{state_key}_{index}"):
            command = option.command
    with st.form(f"{state_key}_form", clear_on_submit=True):
        typed = st.text_input("Ask about F1", max_chars=500, key=f"{state_key}_input")
        submitted = st.form_submit_button("Send")
    if submitted and typed.strip():
        command = typed.strip()
    if command:
        reply = engine.respond(command)
        st.session_state[history_key] = (st.session_state[history_key] + [
            {"role": "user", "content": command},
            {"role": "assistant", "content": reply.text},
        ])[-20:]
    with transcript:
        for message in st.session_state[history_key]:
            with st.chat_message(message["role"]):
                st.markdown(message["content"])
