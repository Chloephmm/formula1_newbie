from datetime import date
from collections.abc import Mapping

from f1buddy_ai.models import HostContext, RaceInfo, PodiumPrediction


def context_from_display(
    *, as_of_date: date, displayed_race: Mapping | None,
    has_real_grid: bool, driver_names: Mapping[str, str],
    team_names: Mapping[str, str],
) -> HostContext:
    if displayed_race is None:
        return HostContext(as_of_date=as_of_date)
    race_date = date.fromisoformat(displayed_race["race"])
    # Exactly the same row choice already used by the host's podium_html().
    using_real = has_real_grid and "podium_real" in displayed_race
    rows = displayed_race["podium_real"] if using_real else displayed_race["podium"]
    prediction = [
        PodiumPrediction(
            code=code, driverName=driver_names.get(code, code),
            team=team_names.get(team, team),
            # Convert display units only; do not recompute or normalize the model.
            podiumProbability=float(display_percent) / 100,
        )
        for code, team, display_percent in rows
    ]
    return HostContext(
        as_of_date=as_of_date,
        current_race=RaceInfo(
            name=displayed_race["name"], season=race_date.year,
            round=displayed_race["round"], date=race_date,
            qualifyingDate=displayed_race.get("quali"),
        ),
        has_real_grid=using_real,
        current_prediction=prediction,
    )
