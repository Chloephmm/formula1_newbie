"""F1 Buddy read-only chatbot components."""

from f1buddy_ai.ui.streamlit import render_chatbot, render_chatbot_panel

__all__ = ["render_chatbot", "render_chatbot_panel"]
